export enum BoardMemberType {
  ADMIN = 'ADMIN',
  MEMBER = 'MEMBER',
}
