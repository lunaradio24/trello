export const MAX_NUM_LISTS_IN_BOARD = 10;
export const INITIAL_POSITION_FACTOR = 1024;

// 위치 값의 곱셈 인자
export const POSITION_MULTIPLIER = 2;

// 위치 재계산 임계값
export const POSITION_RECALCULATION_THRESHOLD = 0.2;
