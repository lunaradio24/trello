export const EXPIRATION_TIME_IN_SECONDS = 9 * 60 * 60; // 9시간을 초 단위로 변환 32400초
