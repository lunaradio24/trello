---
name: Bug report
about: 버그 리포트 이슈 템플릿
title: ''
labels: ''
assignees: ''

---

**버그 발생한 API**

**버그 설명**

**버그 발생 경로**

1. Go to '...'
2. Click on '....'
3. Scroll down to '....'
4. See error

**스크린샷**

**Desktop:**

- OS: [e.g. iOS]
- Browser [e.g. chrome, safari]
- Version [e.g. 22]

**Smartphone:**

- Device: [e.g. iPhone6]
- OS: [e.g. iOS8.1]
- Browser [e.g. stock browser, safari]
- Version [e.g. 22]
